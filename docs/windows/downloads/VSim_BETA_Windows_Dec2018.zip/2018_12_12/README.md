# VSim

3D viewer and presentation tool for historical models

[setup](docs/setup.md)

[building dependencies](docs/dependencies.md)

[vsim format](docs/vsimformat.md)

[code notes](docs/code.md)

[diagrams](docs/diagrams.md)